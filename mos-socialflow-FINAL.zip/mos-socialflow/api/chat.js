/**
 * Mo's-SocialFlow — Secure Anthropic API Proxy
 * ═══════════════════════════════════════════════
 * Sits between the browser and Anthropic's API.
 * Your ANTHROPIC_API_KEY never reaches the client.
 * Supports real-time streaming so all 7 agents
 * stream tokens live back to the dashboard.
 *
 * Vercel Serverless Function (Node.js runtime)
 */

export default async function handler(req, res) {

  // ── CORS preflight ──────────────────────────────────────
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // ── Only allow POST ─────────────────────────────────────
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // ── API key guard ───────────────────────────────────────
  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(500).json({
      error: 'ANTHROPIC_API_KEY is not configured. ' +
             'Add it in Vercel → Project → Settings → Environment Variables.'
    });
  }

  try {
    const body = req.body;

    // ── Safety caps — prevent runaway costs ────────────────
    const safeBody = {
      ...body,
      model:      body.model || 'claude-sonnet-4-20250514',
      max_tokens: Math.min(body.max_tokens || 1000, 2000),
    };

    const isStreaming = safeBody.stream === true;

    // ── Forward to Anthropic ────────────────────────────────
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type':      'application/json',
        'x-api-key':         process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify(safeBody),
    });

    // ── Stream mode — pipe SSE straight through ─────────────
    if (isStreaming) {
      res.setHeader('Content-Type',  'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection',    'keep-alive');

      const reader  = upstream.body.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        res.write(decoder.decode(value, { stream: true }));
      }

      return res.end();
    }

    // ── Non-streaming — return JSON ─────────────────────────
    const data = await upstream.json();
    return res.status(upstream.status).json(data);

  } catch (err) {
    console.error('[mos-socialflow proxy]', err.message);
    return res.status(500).json({ error: err.message || 'Proxy error' });
  }
}
